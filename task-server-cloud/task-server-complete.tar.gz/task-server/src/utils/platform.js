const os = require('os');

class PlatformUtils {
  static isMacOS() {
    return os.platform() === 'darwin';
  }

  static isLinux() {
    return os.platform() === 'linux';
  }

  static isWindows() {
    return os.platform() === 'win32';
  }

  static getPlatform() {
    return os.platform();
  }

  static getAvailableProviders() {
    const providers = [];
    
    // Apple Reminders only available on macOS
    if (this.isMacOS()) {
      providers.push('apple');
    }
    
    // Microsoft and Google work everywhere
    providers.push('microsoft', 'google');
    
    return providers;
  }

  static isProviderAvailable(provider) {
    return this.getAvailableProviders().includes(provider);
  }

  static getDefaultProvider() {
    // Use Apple on macOS if available
    if (this.isMacOS()) {
      return 'apple';
    }
    
    // Otherwise default to Microsoft (more common in business environments)
    return 'microsoft';
  }

  static getPlatformInfo() {
    return {
      platform: this.getPlatform(),
      isMacOS: this.isMacOS(),
      isLinux: this.isLinux(),
      isWindows: this.isWindows(),
      availableProviders: this.getAvailableProviders(),
      defaultProvider: this.getDefaultProvider()
    };
  }
}

module.exports = PlatformUtils;
